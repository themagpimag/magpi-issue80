def update(): # Pygame Zero update function
    global player, timer
    mt = 0
    if player["moveDone"] == True:
        if keyboard.left: mt = doMove(player, -1, 0)
        if keyboard.right: mt = doMove(player, 1, 0)
        if keyboard.up: mt = doMove(player, 0, -1)
        if keyboard.down: mt = doMove(player, 0, 1)
    if mt == 4:
        mapData["data"][ player["y"] + player["queueY"]][ player["x"] + player["queueX"]] = 1
        player["dynamite"] += 1
    updateBall(player)
    updateBall(enemy1)
    updateBall(enemy2)
    updateEnemy(enemy1)
    updateEnemy(enemy2)
