<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="BasicTiles" tilewidth="64" tileheight="64" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="64" height="34" source="../images/map1c.png"/>
 </tile>
 <tile id="1">
  <image width="64" height="64" source="../images/map2c.png"/>
 </tile>
 <tile id="2">
  <image width="64" height="34" source="../images/map3c.png"/>
 </tile>
 <tile id="3">
  <image width="64" height="64" source="../images/dmmap.png"/>
 </tile>
</tileset>
